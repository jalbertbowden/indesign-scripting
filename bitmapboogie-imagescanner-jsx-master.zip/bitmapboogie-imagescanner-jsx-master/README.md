bitmapboogie-imagescanner-jsx
=============================

This is an ExtendScript for importing data from the [bitmapboogie-imagescanner-of](https://github.com/fabiantheblind/bitmapboogie-imagescanner-of) into After Effects
