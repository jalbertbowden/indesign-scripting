![AVATAR IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/avatar/ce0311.png)

Hi,
---
I'm Constantin ([ce0311](https://github.com/ce0311)), interface design student at University of Applied Science in Potsdam. The following project is the result of the course "typography and automation" by [Fabian Morón Zirfas](https://github.com/fabiantheblind).


TypoFlower 
=====
A small script to generate radial patterns from single letters or words.

![splash](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/preview_1_ce0311.png)  

https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/CharSweeper_teaser2.png

[typoflower_01.jsx](https://github.com/fabiantheblind/auto-typo-adbe-id/blob/master/ce0311/typoflower_01.jsx)
---
 
Just edit the variables at the top of the script to change its behaviour.

The comments should be self-explanatory - if not, yell at me!


![splash](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/preview_2_ce0311.png) 

![splash](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/preview_3_ce0311.png) 

Misc
---

Works with InDesign CS6

License  
---

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE  
Version 2, December 2004  

 Copyright (C) 2012 ce0311 (please use github to contact me)
 Everyone is permitted to copy and distribute verbatim or modified copies of this license document, and changing it is allowed as long as the name is changed.  

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE  
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION  
http://sam.zoy.org/wtfpl/

`0. You just DO WHAT THE FUCK YOU WANT TO.  `