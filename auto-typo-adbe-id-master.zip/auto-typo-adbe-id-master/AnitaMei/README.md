![MY AVATAR](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/avatar/anitamei.png)

Howdy
---
my name is [Anita](https://gist.github.com/AnitaMei).

myRPG.jsx  
---
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/am_teaser_1_anita.png)  
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/am_teaser_2_anita.png)  

This is the first start of a script for a simple computer role-playing game.
The users task is it to find its way from home to the university campus.
While traveling the user has to answer questions which are effecting its destiny.
Going through the questions step by step the InDesign document builds up a text frame describing the user's journey.  An info-graphic on the bottom of the document will show the user's journey.  
After completing all quest the user can print the file as an A3 document.  
![TEASER](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/additional/rollenspielablauf_anita.png)  
[https://gist.github.com/3874630]( https://gist.github.com/3874630)  
  

License  
---
![http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png](http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png)

myRPG.jsx by AnitaMei is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
Based on a work at https://gist.github.com/3874630.