![Avatar Image](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/avatar/ferdinandp.png)
#Hello,  
my name is Ferdinand. I'm an Design-Student at University of applied science in Potsdam.

###cmyk_colors.jsx  
 
![Teaser Image](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/fp_cmyk_colors_teaser.png) 
The cmyk_colors.jsx script creates a colour chart for CMYK colors. It can be used to print a color chart for your specific printer with a specific paper you might use freqently. The script can be adjusted by the amount steps per C, M, Y values. Every CMY value creates 6 colors with different K values. You can choose between 1 to 6 steps per C M Y value;  
The script will than create up to 306 colorsheeds with 6 colors.  
[TO THE CMYK_COLOR-SCRIPT](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/master/FerdinandP/cmyk_colors.jsx)  
**the script uses the font :  DIN Next LT Pro for the CMYK value output.**  


###Pagenumber_color_gradation.jsx  

![Teaser Image](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/fp_pagenumber_color_gradation_teaser.png)   

The Pagenumber_ color_gradation.jsx script creates pagesnumbers with a color gradation between frist and last number. It uses the aktiv Indesign document.  
It can be adjusted by  
- changing the CMYK value of the color of the first and the last pagesnumber.  
- changing distance of the pagesnumbers from bottom and side of the document  
- changing the font, fontsize and fontweight  
It works with and without facing pages.  

[TO THE PAGENUMBER_COLOR_GRADATION-SCRIPT](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/master/FerdinandP/pagenumber_color_gradation.jsx)

###misc  
You can also clone the project with [Git](http://git-scm.com) by running:  

    #CMYK colors  
    git clone git://gist.github.com/3877719.git  

<br>  

    #Pagenumber_ color_gradation  
    git clone git://gist.github.com/3877709.git  


##License  

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE Version 2, December 2004
Copyright (C) 2012 USER NAME username@gmail.com Everyone is permitted to copy and distribute verbatim or modified copies of this license document, and changing it is allowed as long as the name is changed.
DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION http://sam.zoy.org/wtfpl/
0. You just DO WHAT THE FUCK YOU WANT TO.
