![AVATAR IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/avatar/natael.png)

Hello
---
my name is julian ([natael](https://github.com/natael))
and this is my project for "typography and automation".

swissd.jsx
---
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/a_teaser_natael.png)

with swissd.jsx you can generate a width-fixed typo.

all you have to do, is to customize the config-object
in the script and run it.

several customizations are possible:
+ add a shadow
+ add shear
+ add a rotation
+ improve the contrast of the biggest words
+ add a vignette (gradient with transparency)
+ add a perspective (3D)

[https://github.com/natael/swissd](https://github.com/natael/swissd)

misc
---
have fun <3

License
---

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
Version 2, December 2004

 Copyright (C) 2012 natael
 Everyone is permitted to copy and distribute verbatim or modified copies of this license document, and changing it is allowed as long as the name is changed.

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
http://sam.zoy.org/wtfpl/

`0. You just DO WHAT THE FUCK YOU WANT TO.  `
