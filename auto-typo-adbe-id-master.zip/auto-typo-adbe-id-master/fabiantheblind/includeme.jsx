    /*
    author: @fabiantheblind
    This file does not get execudet
    it only works together with
    inlcudehere.jsx and has to be next to it
    
    */

// store data in this file to keep your code tidy
// call data from the other file
var data = {
        "pw":100,
        "ph":100,
        "anchors":[
            [  0,50],
            [ 10,60],
            [ 20,40],
            [ 30,60],
            [ 40,40],
            [ 50,60],
            [ 60,40],
            [ 70,60],
            [ 80,40],
            [ 90,60],
            [100,50]
        ]
    };