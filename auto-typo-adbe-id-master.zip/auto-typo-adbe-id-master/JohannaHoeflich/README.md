![Avatar](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/avatar/johannahoeflich.png)  
Hello
My name is Johanna. I just started the master program at the Design Faculty of Potsdam.  

###Projekt_TEXT.jsx
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/jh_Projekt_TEXT.png)   
This Script is a template to design the first text page of a book´s chapter. At the beginning of the script you can type in the number and the name of the chapter as well as the text. You need to decide where to set the breaks of the text. The number you are typing into the line "content_num" will be the initial of the text block.  
[link to your script](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/master/JohannaHoeflich/Projekt_TEXT.jsx)  

###Projekt_AUFMACHER_GRAFIK.jsx
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/jh_Projekt_AUFMACHER_GRAFIK.png)   
This Script is a template to design the leading page of a book´s chapter. At the beginning of the script you can type in the number and the name of the chapter. The script will generate an image of the character you are writing into the variable "content_num". The typographic image is made by duplicating and transforming your character.  
[link to your script](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/master/JohannaHoeflich/Projekt_AUFMACHER_GRAFIK.jsx)  

###Projekt_AUFMACHER_KREIS.jsx
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/jh_Projekt_AUFMACHER_KREIS.png)   
This Script is a template to design the leading page of a book´s chapter. At the beginning of the script you can type in the number and the name of the chapter. The script will generate an image of the character you are writing into the variable "content_num". The typographic image is made by duplicating and rotating your character.  
[link to your script](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/master/JohannaHoeflich/Projekt_AUFMACHER_KREIS.jsx)  

###Projekt_AUFMACHER_ZWIRBEL.jsx
![TEASER IMAGE](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/gh-pages/assets/images/teaser/jh_Projekt_AUFMACHER_ZWIRBEL.png)  
 This Script is a template to design the leading page of a book´s chapter. You can choose what ever lines you want. The script will generate an image of the character you are writing into the according line of the code. The typographic image is made by duplicating, moving and rotating your character.  
[link to your script](https://raw.github.com/fabiantheblind/auto-typo-adbe-id/master/JohannaHoeflich/Projekt_AUFMACHER_ZWIRBEL.jsx)  

###misc
For all these scripts you need to define your own fonts.  

###License
DO WITH THAT WHAT EVER YOU LIKE   
Version 1, October 2012  
Copyright (C) 2012 Johanna Hoeflich johanna.hoeflich@yahoo.de Everyone is permitted to copy and distribute verbatim or modified copies of this license document, and changing it is allowed as long as the name is changed.
DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION http://sam.zoy.org/wtfpl/
0. You just DO WHAT THE FUCK YOU WANT TO.
