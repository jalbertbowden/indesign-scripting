﻿//DESCRIPTION: Create an HTML preset using the active document's Export settings.

if (app.documents.length == 0) {
	alert ('Please open a document.');
	exit();
}

var preset_name = get_filename();
write_html_preset (preset_name);


function get_filename () {
	var w = new Window ('dialog', 'Save HTML preset', undefined, {closeButton: false});
		var dir = script_dir();
		var g = w.add ('panel {orientation: "row"}');
			g.add ('statictext {text: "Preset name: "}');
			var e = g.add ('edittext {characters: 40, active: true}');
		var buttons = w.add ('group {alignment: "right"}');
			buttons.add ('button', undefined, 'Cancel', {name: 'cancel'});
			buttons.add ('button', undefined, 'OK', {name: 'ok'});

	if (w.show() == 1){
		return check_name (dir+e.text);
	} else {
		exit();
	}
}


function write_html_preset (fstring) {
    var array = [],
			obj = app.activeDocument.htmlExportPreferences,
			props = obj.reflect.properties;

    for (var i = 0; i < props.length; i++){
		if (!skip(props[i].name)){
			try {array.push (props[i].name + ': ' + obj[props[i].name])} catch (_){}
		}
	}
    array.sort ();
	var f = File (fstring);
	f.open('w');
	f.write (array.join ('\r'));
	f.close();
}


function skip (s) {
	// serverPath and imageExtension can't be set in the interface, the others we never want
	return '__proto__|eventListeners|events|isValid|parent|properties|serverPath|imageExtension'.indexOf (s) > -1;
}


function check_name (fstring) {
	if (fstring.search (/\.html_preset$/) < 0)
		fstring += '.html_preset';
	var f = File (fstring);
	if (f.exists == false || ask_yn ('Replace ' + fstring.replace (/\.html_preset$/i, "") + '?')){
		return fstring;
	} else {
		return "";
	}
}


function ask_yn (s) {
	var w = new Window ('dialog');
		var t = w.add ('group');
			t.add ('statictext', undefined, s);
		var b = w.add ('group');
			b.add ('button', undefined, 'Yes', {name: 'ok'});
			b.add ('button', undefined, 'No', {name: 'cancel'});
	var temp = w.show ();
	w.close ();
	return temp == 1;
}


function script_dir () {
	try {return File (app.activeScript).path + '/'}
	catch (e) {return File (e.fileName).path + '/'}
}
