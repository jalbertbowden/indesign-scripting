# Scripts for Adobe Illustrator

JavaScript scripts for Adobe Illustrator CSx.  
Test environment: Adobe Illustrator CS3, CS6 (Windows) 

Visit [the project page](http://shanfan.github.com/Illustrator-Scripts-Archive/) for a complete instruction on how these scripts works.
