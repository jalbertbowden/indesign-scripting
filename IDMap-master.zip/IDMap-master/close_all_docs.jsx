// Like Uncle Ben saz: "With great power comes great responsability!"
app.documents.everyItem().close(SaveOptions.NO);