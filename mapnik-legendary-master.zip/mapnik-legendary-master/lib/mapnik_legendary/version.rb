# encoding: utf-8

module MapnikLegendary
  VERSION = '0.1.0'
end
