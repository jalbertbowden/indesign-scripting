﻿// --------------------------------------------------------------
// @@@BUILDINFO@@@ ESTKResources.jsx 2.10 Fri May 23 2014 21:39:09 GMT+0300
// Обзор ESTK констант
// --------------------------------------------------------------
// © Вячеслав aka Buck, 2014. slava.boyko#hotmail.com

#include "../_util.jsx";
// Технический релиз
// #include"src/ESTKResources/ESTKResources.jsx"
// Последний релиз
$.evalFile(File($.fileName).parent + "/contrib/ESTKResources/ESTKResources.jsxbin");

// Использование:
// ---
// В открывшемся окне можно просмотреть значения всех констант