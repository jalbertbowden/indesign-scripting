# ESTKResources

Обзор ESTK констант

**Copyright:** © Вячеслав aka Buck, 2014. <slava.boyko@hotmail.com>