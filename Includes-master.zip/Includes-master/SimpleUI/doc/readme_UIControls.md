# SimpleUI
***Status:*** *Редактируемая версия...* | ***Version:*** *0.1* | ***Last update:*** *25.05.2014*

Содержит несколько вспомогательных функций общего назначения и небольшую коллекцию расширенных элементов управления:

Методы:			| Краткое описание
--------------- | ----------------
isContainer() 	|
WindowInit()	|

Элементы управления:	| Краткое описание
----------------------- | ----------------
Separator (`SeparatorInit(target);`)	| Динамический сепаратор, `SeparatorInit(target)` - метод инициализации сепаратора; 
ProgressBar()			| Расширенный Прогрессбар;
addScrollablePanel()	| Функция, возвращающая скроллируемую панель;
addWebLink()			| функция, преобразующая **StaticText** в элемент **WebLink**

// В процессе...

----------------------------------
**Copyright:** © Вячеслав aka Buck, 2013-2014. <slava.boyko@hotmail.com>

**License:** Creative Commons (NonCommercial) [CC BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/3.0/)