# ESTKLib
***Status:*** *Редактируемая версия...* | ***Version:*** *0.1* | ***Last update:*** *25.05.2014*

Графические ресурсы ExtendScript Toolkit.

Содержит константы графических ресурсов ESTK в ESTK.ICONS (ICONS экспортируется в глобальное пространство имён) и методы для работы с ними.

// В процессе...

#### Дополнительная информация:
В папке *<корень библиотек>/Tools/* присутствует демонстрационная программа [ESTKResources](../../Tools/ESTKResources.md) - которая позволяет в наглядной форме просмотреть значения всех констант **ESTK**.

----------------------------------
**Copyright:** © Вячеслав aka Buck, 2013-2014. <slava.boyko@hotmail.com>

**License:** Creative Commons (NonCommercial) [CC BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/3.0/)