﻿// --------------------------------------------------------------
// @@@BUILDINFO@@@
// MyClass
// --------------------------------------------------------------
// Зависимости
// #include ""

/**
 * @class   MyClass
 * @summary Объект <b>MyClass</b>.
 * @desc    TODO: //
 *
 * 
 * @example <caption>Создание объекта:</caption>
 * // TODO:
 * var myObj = new MyClass();
 */

function MyClass(name) {
    // TODO:
    this.name = (name)||"";
};