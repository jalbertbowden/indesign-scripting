/**
 * @namespace
 */
var namespace = namespace || {};