/**
 * Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam
 * @class
 */
var Parent = function () {
};

Parent.prototype = /** @lends Parent.prototype */{
    /**
     * cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidata
     * @property {String}
     */
    testProperty: '',

    /**
     * Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
     * @param {String|String[]} [paramA=Default Value] tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam
     * @param {namespace.Car} [paramB] quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
     * @param {Function} [paramCallback]
     * @param {String} paramCallback.firstParam
     * @param {String} paramCallback.secondParam
     * @return {Array|Object} consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
     */
    testMethod: function (paramA, paramB, paramCallback) {
        return {};
    }
}