﻿/***********************************************************************************************************
        Align selected Image(s) to Text Baseline
        Version : 1.1a
        Type : Script
        InDesign : CS5.x
        Author : Marijan Tompa (tomaxxi) / Subotica [Serbia]
        Date : 12/12/2011
        Contact : tomaxxi (at) gmail (dot) com
        Web : http://tomaxxi.com
***********************************************************************************************************/

#targetengine tomaxxiENGINE
 
if(parseInt(app.version) >= 7){
    if((function(){
        var gI = false,
            i = 0;
        for(i; i < app.selection.length; i++)
            gI = app.selection[i].hasOwnProperty("graphics")
                && app.selection[i].graphics.length === 1;
        return gI;
    })()){
            var myObj = app.selection,
                myTools = app.toolBoxTools,
                myTool = myTools.currentTool;
            myTools.currentTool = UITools.TYPE_TOOL;
            app.addEventListener("afterSelectionChanged", moveImage);
    }
}else{
    alert("This script requires Adobe InDesign CS5 or newer!", "Error!", true);
}
 
function moveImage(e){
    app.removeEventListener("afterSelectionChanged", moveImage);
    if(app.selection.length
        && app.selection[0].hasOwnProperty("baseline")
        && myObj[0].parentPage === app.selection[0].parentTextFrames[0].parentPage){
            var tB = app.selection[0],
                i = 0;
            app.doScript(doMove, undefined, undefined, UndoModes.ENTIRE_SCRIPT, "Align to Baseline");
            function doMove(){
                for(i; i < myObj.length; i++){
                    myObj[i].move(
                        [myObj[i].geometricBounds[1],
                            (function(){
                                    var tP = app.activeWindow.transformReferencePoint.toString();
                                        if(tP.indexOf("BOTTOM") != -1){
                                            return myObj[i].geometricBounds[0] - myObj[i].geometricBounds[2] + tB.baseline;
                                        }else if(tP.indexOf("CENTER") != -1){
                                            return ((myObj[i].geometricBounds[0] - myObj[i].geometricBounds[2])/2)
                                                + tB.baseline - tB.parent.characters[tB.index].ascent/2;
                                        }
                                    return tB.baseline - tB.parent.characters[tB.index].ascent;
                            }())
                        ]
                    );
                }
            }
        myTools.currentTool = myTool;
        app.select(myObj);
    }
}