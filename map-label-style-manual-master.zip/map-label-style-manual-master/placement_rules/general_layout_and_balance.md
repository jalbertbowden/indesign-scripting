**Text orientation**

For 1:50,000,001 and smaller (global)

Page baseline for point and area text. Line labels hug their lines.

For 1:250,001 to 1:50,000,000 (continent)

Page baseline for point and area text. Line labels hug their lines.
or
The graticule for point and area text. Line labels hug their lines.

For 1:250,000 and larger (city)

Page baseline for point and area text. Line labels hug their lines.

**Balance**

Don't draw text upside down.