***TOOLS***

We include several python scripts in the `tools` directory for implementing the label and abbreviation logic described in this repo.

* [street name abbrevations](https://github.com/nvkelso/map-label-style-manual/tree/master/tools/street_names).