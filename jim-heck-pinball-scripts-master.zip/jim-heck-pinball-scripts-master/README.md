Jim Heck's Scripts for Adobe Illustrator
=============

I publish these scripts on Jim's behalf.

See my blog post about his "remove redundant points" script:
-------
[http://kelsocartography.com/blog/?p=2205](http://kelsocartography.com/blog/?p=2205)

Installation
-------

     1. Quit Illustrator
     2. Copy the files into the Illustrator application folder's "Presets" > "Scripts" subfolder
     3. After restarting Illustrator you can find the scripts in the menu "File" > "Scripts"

TIP: You can create subfolders in the scripts folder to organize your scripts

NOTE: Adopted from a guide by Wolfgang Reszel.