#include 'collator.jsxinc'

function alphaSort()
{
	var s = app.selection,
		i, t, str;

	if( !s.length ) return false;
	
	if( !('contents' in s=s[0]) )
		{
		if( !('parentStory' in s) ) return false;
		s = s.parentStory;
		}
	
	s = s.contents.
		replace(/[\s\.,;:!?]+/g,'|').
		split('|');

	if( s.length > 1000 ) s.length = 1000;
	s.sort(TCollator.compare);
	
	i = s.length;
	t = false;
	while( i-- )
		{
		str = s[i];
		if( str && str!=t)
			{
			t = str;
			continue;
			}
		s.splice(i,1);
		}

	return (s.length && s)||false;
}

var res = alphaSort();
if( false===res )
	alert( "Please select some text!" );
else
	alert( "Alphabetical Sort (default settings):\r\r" + res.join(' | ') );