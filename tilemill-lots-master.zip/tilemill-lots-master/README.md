Experimental plugin for TileMill `pluggable` branch.
