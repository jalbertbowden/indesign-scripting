layout invaders, working alpha

A space invaders inspired game for indesign by Philipp Geuder. Created at the workshop "Typografie und Automation" by Fabian Morón Zirfas at the University of Applied Science Potsdam 2012.


Controls:

- left and right arrow keys to move
- space key to shoot


For most awesome viewing pleasure, make sure to have installed following fonts:

- Helvetica Regular
- Comic Sans MS Regular

- Source Code Pro Regular by Paul D. Hunt | http://sourceforge.net/projects/sourcecodepro.adobe/files/
- CHIP font family by gabrielfigueiredo | http://fontstruct.com/fontstructors/gabrielfigueiredo


Script works with Mac OSX 10.8 and InDesign CS6. 

Not tested with windows and/or older CS versions. Just give it a try and let me know if script breaks ;)


Copyright (c) 2012, Philipp Geuder | philippgeuder.com
Licensed under the MIT license:
http://www.opensource.org/licenses/mit-license.php